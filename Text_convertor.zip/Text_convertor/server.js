// server.js (Backend - Node.js)
const express = require('express');
const multer = require('multer');
const pdfParse = require('pdf-parse');
const Tesseract = require('tesseract.js');
const mammoth = require('mammoth');
const fs = require('fs');
const { getSubtitles } = require('youtube-captions-scraper');
const cors = require('cors');

const app = express();
const upload = multer({ dest: 'uploads/' });
app.use(cors());
app.use(express.json());

// PDF Upload
app.post('/upload/pdf', upload.single('file'), async (req, res) => {
    const dataBuffer = fs.readFileSync(req.file.path);
    const data = await pdfParse(dataBuffer);
    res.json({ text: data.text });
});

// Image Upload
app.post('/upload/image', upload.single('file'), async (req, res) => {
    const imagePath = req.file.path;
    Tesseract.recognize(imagePath, 'eng')
        .then(({ data: { text } }) => res.json({ text }))
        .catch(err => res.status(500).json({ error: err.message }));
});

// DOCX Upload
app.post('/upload/docx', upload.single('file'), async (req, res) => {
    const dataBuffer = fs.readFileSync(req.file.path);
    mammoth.extractRawText({ buffer: dataBuffer })
        .then(({ value }) => res.json({ text: value }))
        .catch(err => res.status(500).json({ error: err.message }));
});

// Function to detect YouTube Shorts vs. Regular Video
function getYouTubeVideoType(videoUrl) {
    if (/\/shorts\//.test(videoUrl)) {
        return "Shorts";
    } else if (/watch\?v=|youtu\.be\//.test(videoUrl)) {
        return "Regular";
    } else {
        return "Unknown";
    }
}

// Function to extract Video ID from both Shorts & Regular YouTube URLs
function extractVideoId(videoUrl) {
    const match = videoUrl.match(/(?:v=|\/shorts\/|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    return match ? match[1] : null;
}

// Fetch subtitles based on Video Type
async function fetchSubtitles(videoId) {
    try {
        console.log("Fetching subtitles for Video ID:", videoId);

        const captions = await getSubtitles({ videoID: videoId, lang: 'en' });

        console.log("Subtitles Response:", captions);

        if (!Array.isArray(captions) || captions.length === 0) {
            console.error("No subtitles found for this video.");
            return null;  // Return null instead of throwing an error
        }

        const subtitleText = captions.map(c => c.text).join(' ');
        console.log("Extracted Subtitles:", subtitleText);

        return subtitleText;
    } catch (err) {
        console.error("Error fetching subtitles:", err);
        return null;  // Return null instead of throwing an error
    }
}

// API Route to Convert Video to Text
app.post('/video', async (req, res) => {
    try {
        const { videoUrl } = req.body;

        // Detect video type (Shorts or Regular)
        const videoType = getYouTubeVideoType(videoUrl);
        console.log("Detected Video Type:", videoType);

        // Extract Video ID
        const videoId = extractVideoId(videoUrl);

        if (!videoId) {
            return res.status(400).json({ error: "Invalid YouTube URL" });
        }

        console.log("Extracted Video ID:", videoId);
        console.log("text ...................")

        // Fetch Subtitles
        try {
            console.log("text ...................")

            if (!videoId) {
                console.error("Error: videoId is undefined or empty.");
            }
            const text = await fetchSubtitles(videoId);
            if (!text) {
                console.error("Error: No subtitles found for videoId:", videoId);
                res.status(404).json({ error: "No subtitles found for video" });
            }
            
            res.json({ type: videoType, text });
        } catch (error) {
            res.status(404).json({ error: error.message });
        }

    } catch (error) {
        console.error("Server error:", error);
        res.status(500).json({ error: "Server error" });
    }
});



app.listen(5000, () => console.log('Server running on port 5000'));
