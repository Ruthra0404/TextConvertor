// File validation (Only PDF, DOC, DOCX, and images)
function fileValidation() {
    const fileInput = document.getElementById("fileInput");
    const file = fileInput.files[0];

    if (!file) return; // No file selected

    const allowedExtensions = ["pdf", "doc", "docx", "jpg", "jpeg", "png"];
    const fileExtension = file.name.split('.').pop().toLowerCase();

    if (!allowedExtensions.includes(fileExtension)) {
        alert("Invalid file type! Please upload a PDF, DOC, DOCX, or an image.");
        fileInput.value = ""; // Clear the input
    }
}

// URL Validation (Only allows valid YouTube URLs)
function validateURL() {
    const videoUrlInput = document.getElementById("videoUrl");
    const fileInput = document.getElementById("fileInput");
    const url = videoUrlInput.value;

    // Regular expression for YouTube URLs
    const youtubeRegex = /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)[a-zA-Z0-9_-]{11}$/;

    if (url.length > 0 && !youtubeRegex.test(url)) {
        videoUrlInput.style.border = "2px solid red";
    } else {
        videoUrlInput.style.border = "";
    }

    // Disable file input if URL is entered
    fileInput.disabled = url.length > 0;
}


async function uploadFile() {
    const file = document.getElementById('fileInput').files[0];
    const formData = new FormData();
    formData.append('file', file);
    
    let endpoint = '/upload/pdf'; // Change based on file type
    if (file.type.includes('image')) endpoint = '/upload/image';
    else if (file.name.endsWith('.docx')) endpoint = '/upload/docx';
    
    const res = await fetch(`http://localhost:5000${endpoint}`, { method: 'POST', body: formData });
    const data = await res.json();
    document.getElementById('output').value = data.text;
}

async function convertVideo() {
    const videoUrl = document.getElementById('videoUrl').value;
    // console.log(videoUrl)
    const res = await fetch('http://localhost:5000/video', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ videoUrl }) });
    const data = await res.json();
    document.getElementById('output').value = data.text;
}